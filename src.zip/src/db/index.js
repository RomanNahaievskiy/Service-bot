export async function initDB() {
  console.log("🗄 DB initialized (stub)");
} // Stub function for database initialization
